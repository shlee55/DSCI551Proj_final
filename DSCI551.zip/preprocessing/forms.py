#from .models import Rawfile
from django.forms import ModelForm

"""
class PostForm(ModelForm):
    class Meta:
        model = Rawfile
        fields = '__all__'

"""